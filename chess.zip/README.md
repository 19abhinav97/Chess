# CS246_Final_Project
Team members
Abhinav Sharma
Larfy Hu
Rishabh Minocha



<h3> Updates </h3>

Rishabh Minocha:

Finished Working on Level 2 AI, working on 3
