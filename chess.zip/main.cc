#include "board.h"
#include "ai_level_1.h"
#include "ai_level_2.h"
#include "board_impl.h"
#include <iostream>
#include "piece_type.h"
#include "colour.h"
#include <string>
#include "invalid_move_exception.h"

using namespace std;

int main(int argc, char *argv[]) {
  Board board;
  board.init(8, 8, 2);
  board.initStandardBoard();
  cout << board;
  /*
  board.setPiece( Position{ 0, 0 }, PieceType::Queen, Colour::White );
  cout << board;
  board.setPiece( Position{ 7, 7 }, PieceType::Pawn, Colour::Black );
  cout << board;
  board.movePiece( Position{ 0, 0 }, Position{ 7, 7 } );
  cout << board;*/
  int n;
  AILevel2Impl* ai_lev1_1 = new AILevel2Impl(Colour::Black);
  AILevel2Impl* ai_lev1_2 = new AILevel2Impl(Colour::White);
  cout << "-----------------------------------------------------------------------\n";
  while(!board.isCheckmate()){
    try{
    ai_lev1_1->doPlayNextMove(&board);
    } catch(InvalidMoveException &e){
      cout << "First player\n";
      cout << e.getErrorMessage() << endl;
    }
    cout << board;
    cin >> n;
    try{
    ai_lev1_2->doPlayNextMove(&board);
    } catch (InvalidMoveException &e){
      cout << e.getErrorMessage() << endl;
    }
    cout << board;
    cin >> n;
  }

}
