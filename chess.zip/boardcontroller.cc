#include "boardcontroller.h"

void BoardController::play() {
  boardcontrollerimpl->play();      
}

