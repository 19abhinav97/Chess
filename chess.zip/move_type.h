#ifndef MOVE_TYPE_H
#define MOVE_TYPE_H

enum class MoveType {

    NewPiece, Move, Capture, IsCaptured

};

#endif
