#ifndef DIRECTION_H
#define DIRECTION_H

enum class Direction {

    NW, N, NE, W, E, SW, S, SE

};

#endif
