#ifndef COLOUR_H
#define COLOUR_H

enum class Colour {

    White=0, Black, Red, Green, Blue, Cyan, Yellow,
    Magenta, Orange, Brown, DarkGreen, NoColour

};

#endif
